# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Board::Application.config.secret_token = '2e14588555485984f7b668c423b1e1ca9825515d8238f49ae0638c942652e9fe6658e5ee72726bf5ee9788ee134c716b624544771d3563817e81f7810848fd12'

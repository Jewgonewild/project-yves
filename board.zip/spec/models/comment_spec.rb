require 'spec_helper'

describe Comment do

end
